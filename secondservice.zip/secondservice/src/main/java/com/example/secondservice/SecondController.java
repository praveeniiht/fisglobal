package com.example.secondservice;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/consumer")
public class SecondController {

	@GetMapping("/message1")
	public String test1() {
		return "Hello GetMapping Called in Second Service";
	}
	
	@PostMapping("/message2")
	public String test2() {
		return "Hello PostMapping Called in Second Service";
	}
	
	@DeleteMapping("/message3")
	public String test3() {
		return "Hello delete mapping called in second service";
	}

}