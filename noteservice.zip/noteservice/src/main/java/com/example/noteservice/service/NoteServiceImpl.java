package com.example.noteservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.noteservice.dao.NotesDao;
import com.example.noteservice.model.Notestab;

@Service
public class NoteServiceImpl implements NoteService{
	
	@Autowired
	NotesDao dao;

	@Override
	public List<Notestab> findAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Notestab addNote(Notestab notes) {
		// TODO Auto-generated method stub
		return dao.save(notes);
	}

	@Override
	public void deleteNote(Notestab notes) {
		// TODO Auto-generated method stub
		dao.delete(notes);
		
	}

	@Override
	public Optional<Notestab> findById(int id) {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

}
