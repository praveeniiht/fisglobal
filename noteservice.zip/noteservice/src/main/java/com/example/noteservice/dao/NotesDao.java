package com.example.noteservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.noteservice.model.Notestab;


@Repository
public interface NotesDao extends JpaRepository<Notestab,Integer>{

}



/*
findAll()--> return all the records
findById(int id) ---> return the specific record based on
the given id;
add() / save()  --> insert the record

delete(id/object)

*/