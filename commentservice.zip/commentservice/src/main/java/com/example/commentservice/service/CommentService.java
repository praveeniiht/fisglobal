package com.example.commentservice.service;

import java.util.List;
import java.util.Optional;

import com.example.commentservice.model.Comment;

public interface CommentService {
	
	public List<Comment> findAll();
	public Comment addComment(Comment comment);
	public void deleteComment(Comment comment);
	public Optional<Comment> findByCommentId(int commentId);
	public List<Comment> findByNoteId(int id);
	

}
