package com.example.commentservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Table(name="comments")
@Data
public class Comment {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int commentId;
		
	@Column(name="pid")
	int pid;
	
	@Column(name="fromAuthor")
	String fromAuthor;
	
	@Column(name="toAuthor")
	String toAuthor;
	
	@Column(name="comment")
	String comment;

}
