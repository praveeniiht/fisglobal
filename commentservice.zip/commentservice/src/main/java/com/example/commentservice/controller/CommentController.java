package com.example.commentservice.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.commentservice.model.Comment;
import com.example.commentservice.service.CommentService;


@RestController
@RequestMapping("/comments")
public class CommentController {
	
	@Autowired
	CommentService service;
	
	@RequestMapping(value="/all", method=RequestMethod.GET)
	public List<Comment> findAll(){
		return service.findAll();
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public Comment addComment(@RequestBody Comment comment) {
		return service.addComment(comment);
	}
	@RequestMapping(value="/del", method=RequestMethod.DELETE)
	public String deleteComment(@RequestBody Comment comment) {
		service.addComment(comment);
		return "Comment Deleted";
	}
	
	@RequestMapping(value="/id/{id}", method=RequestMethod.GET)
	public Optional<Comment> findCommentById(@PathVariable int id)
	{
		return service.findByCommentId(id);
	}
	
	@RequestMapping(value="/note/{id}", method=RequestMethod.GET)
	public List<Comment> findNotesByAuthor(@PathVariable int id){
		return service.findByNoteId(id);
	}

	

}
